// Select DOM elements
const slides = document.querySelector('.slides');
const images = document.querySelectorAll('.gallery-image');
const prevBtn = document.getElementById('prevBtn');
const nextBtn = document.getElementById('nextBtn');
const photoForm = document.getElementById('photoForm');
const photoInput = document.getElementById('photoInput');
const uploadMessage = document.getElementById('uploadMessage');

let currentIndex = 0;
let totalImages = images.length;

// Function to display the current slide
function showSlide(index) {
    const offset = -index * 100;
    slides.style.transform = `translateX(${offset}%)`;
}

// Add event listeners for navigation buttons
prevBtn.addEventListener('click', () => {
    currentIndex = (currentIndex === 0) ? totalImages - 1 : currentIndex - 1;
    showSlide(currentIndex);
});

nextBtn.addEventListener('click', () => {
    currentIndex = (currentIndex === totalImages - 1) ? 0 : currentIndex + 1;
    showSlide(currentIndex);
});

// Initialize first slide
showSlide(currentIndex);

// Handle photo uploads
photoForm.addEventListener('submit', function (event) {
    event.preventDefault();
    
    const file = photoInput.files[0];

    if (file) {
        const reader = new FileReader();

        reader.onload = function (e) {
            const newImageSrc = e.target.result;
            const newImage = document.createElement('img');
            newImage.src = newImageSrc;
            newImage.alt = `New Image ${totalImages + 1}`;
            newImage.classList.add('gallery-image');
            
            // Add the new image to the gallery
            slides.appendChild(newImage);
            totalImages++;

            // Update the currentIndex to display the newly added image
            currentIndex = totalImages - 1;
            showSlide(currentIndex);

            // Provide feedback to the user
            uploadMessage.textContent = "Photo added successfully!";
            setTimeout(() => {
                uploadMessage.textContent = "";
            }, 3000);

            // Clear the input
            photoInput.value = '';
        };

        reader.readAsDataURL(file);
    } else {
        uploadMessage.textContent = "Please select a photo!";
    }
});
